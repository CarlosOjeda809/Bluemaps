<script setup>


import Footer from '~/components/Footer.vue';

</script>

<template>
  
  <div class="flex-col flex-h-screen">
    <NuxtPage class="h-full flex-1"/>
    <Footer />
  </div>
</template>
