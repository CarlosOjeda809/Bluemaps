<script setup>

</script>

<template>
    <header
        class="bg-gradient-to-r from-green-700 to-green-400 text-white px-5 h-16 flex items-center justify-between shadow-md">
        <div class="flex items-center font-bold text-2xl">
            <span class="mr-2 text-3xl">🍃</span>
            <span class="hidden sm:inline">GreenMaps</span>
        </div>
    </header>
</template>

<style lang="postcss" scoped></style>
