<script setup>

</script>

<template>
    <footer class="fixed bottom-0 w-full z-6000 ">
        <div class="text-white bg-green-700 px-5 py-2 flex items-center justify-between shadow-md">
            <div class="flex items-center">
                <span class="text-sm">© 2023 GreenMaps | Explora España</span>
            </div>
        </div>
    </footer>
</template>